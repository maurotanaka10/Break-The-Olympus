using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TiroJogador : MonoBehaviour
{
    //Tiro
    public GameObject bulletProject;
    public Transform gun;
    public float shortSpeed;

    public int danoParaDar;

    //Tiro Especial
    public GameObject tiroEspecial;
    public bool temTiroEspecial;
    public float tempoMaximoDoTiroEspecial;
    public float tempoaAtualDoTiroEspecial;

    //animacao
    private Animator anima;

    // Start is called before the first frame update
    void Start()
    {
        temTiroEspecial = false;

        tempoaAtualDoTiroEspecial = tempoMaximoDoTiroEspecial;

        anima = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Shoot();

        if(temTiroEspecial == true)
        {
            tempoaAtualDoTiroEspecial -= Time.deltaTime;

            if(tempoaAtualDoTiroEspecial <= 0)
            {
                DesativarTiroEspecial();
            }
        }
    }

    private void Shoot()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            if (temTiroEspecial == false)
            {
                GameObject temp = Instantiate(bulletProject);
                temp.transform.position = gun.position;
                temp.GetComponent<Rigidbody2D>().velocity = new Vector2(shortSpeed, 0);
                EfeitosSonoros.instance.somTiroJogador.Play();
                Destroy(temp.gameObject, 1.2f);
            }
            else
            {
                GameObject temp = Instantiate(tiroEspecial);
                temp.transform.position = gun.position;
                temp.GetComponent<Rigidbody2D>().velocity = new Vector2(shortSpeed, 0);
                EfeitosSonoros.instance.somTiroEspecial.Play();
                Destroy(temp.gameObject, 1.2f);
            }

            anima.SetBool("pAtirar", true);
        }
        else
        {
            anima.SetBool("pAtirar", false);
        }

    }

    private void DesativarTiroEspecial()
    {
        temTiroEspecial = false;
        tempoaAtualDoTiroEspecial = tempoMaximoDoTiroEspecial;
    }

    
}
