using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PaineldeGameOver : MonoBehaviour
{
    public void ReiniciarJogo()
    {
        SceneManager.LoadScene(SceneManager.GetSceneAt(1).name);
    }

    public void TelaDeMenu()
    {
        SceneManager.LoadScene(SceneManager.GetSceneAt(0).name);

    }

    public void SairDoJogo()
    {
        Application.Quit();
    }
}
